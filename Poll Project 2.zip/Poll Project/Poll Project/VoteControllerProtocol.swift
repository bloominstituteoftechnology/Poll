//
//  VoteControllerProtocol.swift
//  Poll Project
//
//  Created by Jonathan Ferrer on 4/23/19.
//  Copyright © 2019 Jonathan Ferrer. All rights reserved.
//

import Foundation
class VoteControllerProtocol{
    
    var voteController: VoteController?
    
    }
    

